﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LoginForm : Form
    {
        private const string ConnectionString = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=Database.accdb;";
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string loginuser = textBox1.Text;
            string password = textBox2.Text;

            DataTable table = new DataTable();

            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string query = "SELECT * FROM [Users] WHERE [user] = @ul AND [password] = @up";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ul", loginuser);
                    command.Parameters.AddWithValue("@up", password);
                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    adapter.Fill(table);
                }
            }

            if (table.Rows.Count > 0)
            {
                string userRole = table.Rows[0]["role"].ToString().Trim();

                // В зависимости от роли, открыть нужную форму
                if (userRole.ToLower() == "admin")
                {
                    Form1 mainForm = new Form1();
                    mainForm.Show();
                    this.Hide(); // скрываем форму входа
                }
                else
                {
                    MessageBox.Show("Доступ запрещен для вашей роли.");
                }

                MessageBox.Show("Добро Пожаловать.");
            }
            else
            {
                MessageBox.Show("Ошибка при вводе данных аккаунта.");
            }
        }
    }
}
